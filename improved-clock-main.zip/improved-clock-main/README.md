# improved-clock

Titanium Clock: Infinity Edition. An enterprise-grade, high-performance flip clock and productivity timer.

## How to Run

To view the application locally, you can use any static file server.

### Using Python

```bash
python3 -m http.server 3000
```

Then open `http://localhost:3000` in your browser.
