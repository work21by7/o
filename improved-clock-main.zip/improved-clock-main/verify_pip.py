
from playwright.sync_api import sync_playwright

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        # Removed 'picture-in-picture' permission
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        )
        page = context.new_page()

        # Capture console logs
        page.on("console", lambda msg: print(f"Console: {msg.text}"))
        page.on("pageerror", lambda exc: print(f"PageError: {exc}"))

        print("Navigating...")
        page.goto("http://localhost:8080/index.html")
        page.wait_for_load_state("networkidle")

        print("Page loaded. Clicking PiP button...")
        # Check if button exists
        if page.is_visible("#pipBtn"):
            page.click("#pipBtn")
            print("Clicked PiP button.")
        else:
            print("PiP button not found or not visible!")
            # It might be in the "More" menu if in portrait, but default headless size is usually 1280x720 (landscape)
        
        # Wait a bit to see if an error toast appears
        page.wait_for_timeout(2000)
        
        # Take screenshot
        page.screenshot(path="verification_pip.png")
        print("Screenshot taken.")
        
        browser.close()

if __name__ == "__main__":
    run()
