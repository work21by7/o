
from playwright.sync_api import sync_playwright

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={'width': 1280, 'height': 720}
        )
        page = context.new_page()

        print("Navigating...")
        page.goto("http://localhost:8080/index.html")
        
        # Wait a moment for animations to start/render
        page.wait_for_timeout(1000)
        
        # Take screenshot of the intro overlay
        page.screenshot(path="verification_overlay.png")
        print("Screenshot taken.")
        
        browser.close()

if __name__ == "__main__":
    run()
